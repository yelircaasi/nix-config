# Tmp

* https://github.com/NorfairKing
* https://medevel.com/tag/productivity/ **
* https://medevel.com/cuekeeper/
* https://github.com/pickfire/spt
* https://orgmode.org/worg/org-contrib/

* Elevate Your Task Management With Ease - YouTube https://www.youtube.com/watch?v=U4pGz4KI1J0&t=12s&pp=2AEMkAIB
* https://github.com/adnanh/webhook
* https://www.freedesktop.org/wiki/Software/dbus/ 
* https://develop.kde.org/frameworks/kirigami// 
* https://docs.python.org/3.11/library/argparse.html#module-argparse 
* https://github.com/python-poetry/cleo
* https://rich.readthedocs.io/en/stable/introduction.html 
* https://click.palletsprojects.com/en/8.1.x/ ← looks really good
* https://github.com/chris48s/stage-left, together with 
* https://github.com/dbinagi/nomodoro 
* https://github.com/jakethekoenig/tmux-pom?
* https://github.com/poljar/matrix-nio
* [ ] https://github.com/timeopochin/GanTTY
* [ ] https://github.com/vit-project/vit
* [ ] https://github.com/Textualize/textual 
* → example: https://github.com/Cvaniak/NoteSH
* → https://github.com/Textualize/textual/discussions/165
* [ ] https://github.com/kstenschke/tictac-track
* [ ] https://github.com/klaudiosinani/taskbook
* [ ] https://github.com/darrikonn/td-cli
* [ ] https://github.com/dnote/dnote
* [ ] https://github.com/xwmx/nb
* [ ] https://vhp.github.io/terminal_velocity/
* https://sma.supermemo.wiki/#/ 
* [Pricing - WakaTime](https://wakatime.com/pricing)
* https://github.com/TheRolfFR/activity-tracker 
* https://github.com/anufrievroman/calcure 
* https://github.com/AlphabetsAlphabets/actt 
* [note templates](https://jacobzelko.com/08032021134232-notes-template/#example_of_actual_note)
* https://github.com/wireapp/lithium 
* [Tinycare-Tui](https://www.reddit.com/r/golang/s/fVY4hoTMYY)
* https://www.heise.de/tests/Kurztests-Desktop-Uebersetzer-Markdown-Notizbuch-und-Online-Whiteboard-9201345.html 
* [planager (+ganttouchthis, taskifist)](https://www.notion.so/nebokrai-horizon-consilium-ganttouchthis-taskifist-roadmapper-2d3a6d104fb348c0b63b58087aada71b?pvs=21)
* [JasonShin/fp-core.rs: A library for functional programming in Rust](https://github.com/JasonShin/fp-core.rs)
* https://github.com/brunocbr/zettel-composer
* https://activitywatch.net/ 
* [I Should Have Just Used Vimwiki From The Start](https://youtu.be/vBJj7YMVn6I)
* [u/oohay_email2004 replied to your post in r/codereview - isaac.r.riley@gmail.com - Gmail](https://mail.google.com/mail/u/0/#inbox/FMfcgzGrcXqJsBMnzlVBKMwmsLDGFBrL)
* [Automate the Boring Stuff with Python](https://automatetheboringstuff.com/chapter18/)
* [amiof/todo-list-: a todo list create with js and html & css](https://github.com/amiof/todo-list-)
* [Egnod/karakurt: Cookiecuttrer-template for python cli app](https://github.com/Egnod/karakurt)
* [Introduction - Textual](https://textual.textualize.io/)
* [irq0/whatidid: what I do and what I did](https://github.com/irq0/whatidid)
* [my productivity workflow 2023!](https://youtu.be/IZX-cDR6IQM)
* [BOOKSTORES: How to Read More Books in the Golden Age of Content](https://youtu.be/lIW5jBrrsS0)
* [my productivity workflow 2023!](https://youtu.be/IZX-cDR6IQM)
* [My Get Things Done (GTD) Task](https://www.youtube.com/watch?v=8I7nQmKAWpM) Management System Using
* [How To Use VIT The Curses Based](https://www.youtube.com/watch?v=wY3DJVSWdeI&t=363s) 
* CLI "Digital Assistant"
* [10 Best Free and Open Source Command-Line Python Application Development Tools - LinuxLinks](https://www.linuxlinks.com/best-free-open-source-command-line-python-application-development-tools/)
* [python - Combining pyperclip copy-to-clipboard with pyautogui paste? - Stack Overflow](https://stackoverflow.com/questions/47075240/combining-pyperclip-copy-to-clipboard-with-pyautogui-paste)
* search: vimwiki for android
* [VIMKipedia: Or How I Built My Second Brain Using Vim - YouTube](https://www.youtube.com/watch?v=q80hXvorl0o)
* [Lyaaaaaaaaaaaaaaa/Project_Kanban: A lightweight desktop software, under the MIT licence to create and manage your Kanbans boards for your personal projects](https://github.com/Lyaaaaaaaaaaaaaaa/Project_Kanban)
* [TaskMaster](http://www.kevra.org/TheBestOfNext/ThirdPartyProducts/ThirdPartySoftware/InformationManagement/TaskMaster/TaskMaster.html)
* (9+) Config(9+) planager (ganttstopme?)
* [timeopochin/GanTTY: Project planning from the terminal](https://github.com/timeopochin/GanTTY)
* [I haven't found a decent ToDo list with this killer feature: dependencies. I wan... | Hacker News](https://news.ycombinator.com/item?id=11352791)
* 2 Geeky Tools to Manage Your Sourcing Tasks - SourceCon
* Enum HOWTO -  Python 3.11.2 documentation
* algorithm - Evenly space n items over m iterations - Stack Overflow
* [ganttouchthis/LICENSE at main · yelircaasi/ganttouchthis](https://github.com/yelircaasi/ganttouchthis/blob/main/LICENSE)
* [My integrations | Notion Developers](https://www.notion.so/my-integrations)
* [syncall/readme-tw-notion.md at master · bergercookie/syncall](https://github.com/bergercookie/syncall/blob/master/readme-tw-notion.md)
* [Reddit - Here! Some USEFUL date formulas for your Notion's Setup!](https://www.reddit.com/r/Notion/comments/fsnmmg/here_some_useful_date_formulas_for_your_notions/)
* [My efficient and effective Productivity Setup With Emacs, Org Mode and Org Agenda](https://youtu.be/oG9jP0SsPqQ)
* [Curses Programming with Python — Python 3.11.2 documentation](https://docs.python.org/3/howto/curses.html)
* [curses — Terminal handling for character-cell displays — Python 3.11.2 documentation](https://docs.python.org/3/library/curses.html#module-curses)
* [TiddlyWiki — a non-linear personal web notebook](https://tiddlywiki.com/)
* [msiemens/tinydb: TinyDB is a lightweight document oriented database optimized for your happiness :)](https://github.com/msiemens/tinydb)
* [Welcome to TinyDB! — TinyDB 4.7.1 documentation](https://tinydb.readthedocs.io/en/latest/)
* [curses (programming library) - Wikipedia](https://en.wikipedia.org/wiki/Curses_(programming_library))
* [Taiga 30min Setup - Learn Taiga basics - Taiga Community](https://community.taiga.io/t/taiga-30min-setup/170)
* [kquick/mywork: Tool to keep track of what you have been working on, and where and when work should continue](https://github.com/kquick/mywork)
* [brick: A declarative terminal user interface library](https://hackage.haskell.org/package/brick)
* [zadam/trilium: Build your personal knowledge base with Trilium Notes](https://github.com/zadam/trilium)
* [Paperspace Blog](https://blog.paperspace.com/)
* https://obsidian.md/
* [set up dvc with google drive - Google Search](https://www.google.com/search?client=firefox-b-d&q=set+up+dvc+with+google+drive)
* https://www.youtube.com/watch?v=A1YgbAp5YRc
* [Stuff I did - The stuff I do](https://www.statox.fr/projects/#)
* https://dashboard.heroku.com/account heroku backup XY047RVTHX H0RYMIZ36C VTU7G4K6YO IMDP455R7S P7EN0W7BZP NDWZ0FMG1L ECTT2W4552 ZTICQNARDY 7SUJG65VN8 J1B78S0QOR
* https://github.com/toeverything/AFFiNE
* [Are TODO Applications Hind](https://www.youtube.com/watch?v=BcxZj2qh4Kw)ering Your Productivity?
* https://f-droid.org/packages/com.mhss.app.mybrain/ 
* https://organice.200ok.ch/ 
* https://github.com/AsamK/signal-cli
* https://ecosystem.atlassian.net/wiki/spaces/JRJC/overview 
* https://github.com/PROxZIMA/TimetableScheduler 
* https://github.com/topics/timetable-generator
* https://github.com/nomeata/arbtt - automatic rule-based time tracker
* https://sr.ht/~emersion/goguma/ 
* https://sr.ht/~emersion/gamja/
* https://github.com/ergochat/ergo
* https://github.com/jquku/Matrix-Chatbot
* https://github.com/lwesterhof/semaphore
* https://gitlab.com/signald/signald
* https://signald.org/ 
* https://github.com/signalapp/libsignal
* https://github.com/AsamK/signal-cli
* https://github.com/matrix-org/matrix-hookshot 
* https://play.google.com/store/apps/details?id=com.countercultured.irc4android 
* https://gitlab.com/jpypi/rustix 
* https://matrix.org/ecosystem/integrations/ 
* https://gitlab.com/jpypi/rustix
* https://tasks.org/ $$$$$$$$$
* https://github.com/usememos/memos
* https://xit.jotaen.net/
* https://github.com/orgzly/orgzly-android
* https://www.libhunt.com/r/organice 
* https://org-web.org/ 
* https://appwrite.io/ 
* https://github.com/bgregos/foreground 
* https://f-droid.org/packages/me.bgregos.brighttask/ 
* https://f-droid.org/packages/com.madlonkay.orgro/ → make for neorg
* https://github.com/d-k-bo/gotify-rs 
* https://github.com/gotify/server 
* https://keep.imfreedom.org/pidgin/pidgin/ 
* https://github.com/tinode/chat 
* https://github.com/twilio-labs/receptionist-bot-rs
* https://slack-rust.abdolence.dev/ 
* https://www.pushbits.io/ 
* https://matrix.org/ecosystem/bridges/signal/ 
* https://github.com/matrix-org/matrix-rust-sdk#readme 
* https://matrix.org/ecosystem/sdks/ 
* https://f-droid.org/packages/com.github.gotify/ 
* https://anytype.io/ 
* My GTD Emacs Workflow (Getting Things Done) - YouTube https://m.youtube.com/watch?v=92PCxH29UCo
* https://stackoverflow.com/questions/35250621/recursive-self-referencing-json-schema 
* https://fortelabs.com/blog/test-driving-a-new-generation-of-second-brain-apps-obsidian-tana-and-mem/ 
* https://stackoverflow.com/questions/20752716/json-schema-recursive-schema-definition 
* https://about.org-note.com/ 
* https://libera.chat/guides/clients 
* https://f-droid.org/packages/io.mrarm.irc/ 
* https://sopel.chat/ 
* https://github.com/topics/irc-bot
* https://graz.social/@publicvoit/111388551599358628 
* nebokrai $$$$$$$$$ https://smos.online/ 
* https://julian.digital/2023/07/06/multi-layered-calendars/
* Spaced repetition systems can be used to program attention https://notes.andymatuschak.org/zB92WZZ5baBHKZPPbWMbYEv  
* https://discord.com/channels/834325286664929280/877666474888675368/1222613062796705862
* https://julian.digital/2023/07/06/multi-layered-calendars/
* https://tinydb.readthedocs.io/en/latest/ 
* → switch to https://www.focalboard.com/ ?
* https://www.notion.so/my-integrations 
* via Trello?
* https://github.com/makenotion/notion-sdk-js
* https://github.com/ramnes/notion-sdk-py
* https://github.com/getsyncr/notion-sdk (deprecated)
* https://github.com/makenotion/notion-sdk-typescript-starter 
* [ ] https://github.com/nvim-neorg/neorg
* [gtd books](http://libgen.rs/search.php?req=getting+things+done+David+allen&open=0&res=25&view=simple&phrase=1&column=def)
* https://github.com/MahmoudNasser01/django_simple_notification 
* https://github.com/avelino/awesome-go#advanced-console-uis 
* https://github.com/adnanh/webhook
* https://github.com/schmee/habu 
* [ ] https://github.com/hugginsio/twig.nvim, also a nvim plugin
* https://github.com/nvim-neorg/neorg/wiki/GTD-Queries/ba2cc1c5cf8c5ed0690e445f213e18c04ff4e157 
* [ ] https://github.com/xwmx/nb ***
* [ ] https://github.com/pimutils/todoman
* https://github.com/Rigellute/spotify-tui/issues/732 for spotify-tui on rpi
* https://docs.spotifyd.rs/installation/Raspberry-Pi.html 
* [https://accounts.spotify.com/authorize?response_type=code&state=AV5CzOfJ8YxNnEch&client_id=0cd789e4785c4b19ad5a200822b12104&redirect_uri=http:%2F%2Flocalhost:8888%2Fcallback&scope=playlist-read-collaborative playlist-read-private playlist-modify-private playlist-modify-public user-follow-read user-follow-modify user-library-modify user-library-read user-modify-playback-state user-read-currently-playing user-read-playback-state user-read-playback-position user-read-private user-read-recently-played&](https://accounts.spotify.com/authorize?response_type=code&state=AV5CzOfJ8YxNnEch&client_id=0cd789e4785c4b19ad5a200822b12104&redirect_uri=http:%2F%2Flocalhost:8888%2Fcallback&scope=playlist-read-collaborative%20playlist-read-private%20playlist-modify-private%20playlist-modify-public%20user-follow-read%20user-follow-modify%20user-library-modify%20user-library-read%20user-modify-playback-state%20user-read-currently-playing%20user-read-playback-state%20user-read-playback-position%20user-read-private%20user-read-recently-played&)
* https://developer.spotify.com/dashboard
* https://github.com/phaazon/mind → also look at how keymaps are handled and represented
* https://github.com/Nighty3098/FocuseSpace 
* [palette::named - Rust](https://docs.rs/palette/0.4.1/palette/named/index.html#constants)
* [rdbo/sigma-linux: Sigma Linux - Σlite Operating System](https://github.com/rdbo/sigma-linux)
* [johannesjo/super-productivity: Super Productivity is an advanced todo list app with integrated Timeboxing and time tracking capabilities. It also comes with integrations for Jira, Gitlab, GitHub and Open Project.](https://github.com/johannesjo/super-productivity)
* [Python 3.12 Generic Types Explained ArjanCodes ArjanCodes Verificada • • 5,2 K visualizaciones hace 5 horas Nuevo](https://www.youtube.com/watch?v=q6ujWWaRdbA)
* [Building Implicit Interfaces in Python with Protocol Classes](https://andrewbrookins.com/technology/building-implicit-interfaces-in-python-with-protocol-classes/)
* [Protocols in Python: Why You Need Them - GoDataDriven](https://godatadriven.com/blog/protocols-in-python-why-you-need-them/)
* [How to create module-wide variables in Python? - Stack Overflow](https://stackoverflow.com/questions/1977362/how-to-create-module-wide-variables-in-python)
* [Body Weight Planner - NIDDK](https://www.niddk.nih.gov/bwp)
* [Colored and Clickable Wrapping URLs in LaTeX and LyX](http://troubleshooters.com/linux/lyx/urlwrap.htm)
* [mtkennerly/poetry-dynamic-versioning: Plugin for Poetry to enable dynamic versioning based on VCS tags](https://github.com/mtkennerly/poetry-dynamic-versioning)
* [TagTrees: Improving Personal Information Management Using Associative Navigation- on screen version](https://karl-voit.at/tagstore/downloads/Voit2012b.pdf)
* [The Tag «pim»](https://karl-voit.at/tags/pim/)
* [Task management with Taskwarrior and Taskell](https://tallguyjenks.github.io/blog/task-management-with-taskwarrior-and-taskell.html)
* [Block Elements - Wikipedia](https://en.wikipedia.org/wiki/Block_Elements)
* [proglang table](https://www.notion.so/189fb9f08c944ab3ba2c284a4fb09445?pvs=21)
* [GitPython/git/diff.py at main · gitpython-developers/GitPython](https://github.com/gitpython-developers/GitPython/blob/main/git/diff.py)
* [difflib — Helpers for computing deltas — Python 3.12.0 documentation](https://docs.python.org/3/library/difflib.html)
* [annotated-types/annotated_types/__init__.py at main · annotated-types/annotated-types](https://github.com/annotated-types/annotated-types/blob/main/annotated_types/__init__.py)
* [Pytest With Eric](https://pytest-with-eric.com/)
* [Welcome to Pydantic - Pydantic](https://docs.pydantic.dev/latest/)
* [Pytest With Eric](https://pytest-with-eric.com/)
* [pywal/pywal/backends/wal.py at master · dylanaraps/pywal](https://github.com/dylanaraps/pywal/blob/master/pywal/backends/wal.py)
* [JSON Schema](https://json-schema.org/understanding-json-schema)
* [JSON Schema - object](https://json-schema.org/understanding-json-schema/reference/object#regexp)
* [JSON Schema 2020-12](https://www.learnjsonschema.com/2020-12/)
* [GitHub - rdbo/sigma-linux: Sigma Linux - Σlite Operating System](https://github.com/rdbo/sigma-linux)
* [Install Ubuntu Server | Ubuntu](https://ubuntu.com/tutorials/install-ubuntu-server#6-choose-your-install)
* [Create a Bootable Device - Alpine Linux](https://wiki.alpinelinux.org/wiki/Create_a_Bootable_Device)
* nebokrai & similar
* https://github.com/simplex-chat/simplex-chat/tree/stable/apps 
* https://github.com/simplex-chat/simplex-chat/blob/stable/apps/simplex-bot-advanced/Main.hs 
* https://simplex.chat/blog/20231125-simplex-chat-v5-4-link-mobile-desktop-quantum-resistant-better-groups.html 
* SchildiChat https://f-droid.org/packages/de.spiritcroc.riotx/ 
* Best Secure Messaging App | FBI Document Leaked - YouTube https://www.youtube.com/watch?v=wj-aR96FOA0&pp=ygUPU2lnbmFsIGNoYXQgYm90 
* [types-jsonschema · PyPI](https://pypi.org/project/types-jsonschema/#history)
* [nebokrai/.envrc at main · yelircaasi/nebokrai](https://github.com/yelircaasi/nebokrai/blob/main/.envrc)
* [SSH and GPG keys](https://github.com/settings/keys) 
* ⇒ https://wiki.archlinux.org/title/List_of_applications/Other
* https://jamesclear.com/how-to-stop-procrastinating
* https://www.jeffsanders.com/the-7-essential-elements-of-productivity-element-4-planning/ 
* [HedgeDoc - The best platform to write and share markdown.](https://hedgedoc.org/)
* [hedgedoc/hedgedoc at blog.cloudron.io](https://github.com/hedgedoc/hedgedoc?ref=blog.cloudron.io)
* [https://github.com/viseshrp/workedon](https://github.com/viseshrp/workedon)
* https://github.com/teloxide/teloxide
* https://github.com/tools-life/taskwiki
* [Ticketsystem: Znuny 7 als Open-Source-Alternative zu OTRS](https://www.heise.de/news/Ticketsystem-Znuny-7-als-Open-Source-Alternative-zu-OTRS-8969167.html)
* (Telegram inline keyboard? Add [custom keyboard](https://www.google.com/search?q=add+custom+keyboard+to+android&sxsrf=APwXEde_qAYevpIXgyBDpVjjtVpsAK4Huw:1682273314975&source=lnt&tbs=qdr:y&sa=X&ved=2ahUKEwjvrOq6zMD-AhUCsaQKHZB0BsEQpwV6BAgBEAs&biw=1717&bih=845&dpr=1) for Telegram to include slash and numbers on basic keyboard? → not highest priority)
* https://www.npmjs.com/package/browser-sync 
* [Is there a plugin for seeing a live preview of HTML/CSS/JS?Reddithttps://www.reddit.com › neovim › comments › plggq3](https://www.reddit.com/r/neovim/comments/plggq3/is_there_a_plugin_for_seeing_a_live_preview_of/)
* I use markdown-*preview*.*nvim* for getting a *live preview* when editing Markdown files. But is there something similar for web development?
* [Is there a plugin for *live preview* my web projects on ... - Reddit](https://www.reddit.com/r/neovim/comments/uzqx2i/is_there_a_plugin_for_live_preview_my_web/)
* [Live* Server plugin for *vim*/*nvim* : r/*neovim* - Reddit](https://www.reddit.com/r/neovim/comments/w86ash/live_server_plugin_for_vimnvim/)
* [Introducing *live*-command.*nvim*: *preview* the norm ... - Reddit](https://www.reddit.com/r/neovim/comments/xx5hhp/introducing_livecommandnvim_preview_the_norm/)
* [Live* markdown *preview* to PDF : r/*neovim* - Reddit](https://www.reddit.com/r/neovim/comments/w7ki77/live_markdown_preview_to_pdf/)
* https://dev.to/fidelve/using-vim-as-your-main-editor-for-web-development-5a73 
* https://www.google.com/search?client=firefox-b-d&q=open+source+web+gantt+viewer 
* https://github.com/litehtml/litehtml 
* https://github.com/edluffy/hologram.nvim 
* https://github.com/krivahtoo/silicon.nvim
* Read https://neovim.io/doc/user/lua.html
* Read https://learnxinyminutes.com/docs/fr-fr/lua-fr/, https://learnxinyminutes.com/docs/pt-br/lua-pt/,  https://learnxinyminutes.com/docs/de-de/lua-de/, https://learnxinyminutes.com/docs/ru-ru/lua-ru/
* Read https://www.lua.org/manual/5.1/1
* https://www.reddit.com/r/Notion/comments/nd76ec/notion_api_webhooks/ 
* https://www.thegist.so/#Pricing 
* (productivity) https://github.com/matthiasn/lotti 
* [Whimsical - Work Better, Faster, Together](https://whimsical.com/) 
* https://ramnes.github.io/notion-sdk-py/ 
* https://foambubble.github.io/foam/ 